package com.example.lukeoop;
// module class for representing the module objects
public class Module {
    private String moduleName;
    private String grade;

    public Module(int id, String moduleName, String grade, String semester) {
        this.moduleName = moduleName;
        this.grade = grade;
    }

}
