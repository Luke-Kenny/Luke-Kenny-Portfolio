package com.example.lukeoop;

// grade class for representing grade object
public class Grade {
    private String id;
    private String module_name;
    private String grade;

    public Grade(String id, String module_name, String grade) {
        this.id = id;
        this.module_name = module_name;
        this.grade = grade;
    }

}
