package com.example.lukeoop;

import java.sql.*;

/**
    this is my model class for MVC design patter which secures the connection to the database called MTU_Records
    this DB contains 3 tables, students, modules and grades
    the students table contains the following attributes: id(student id), name, dob(date of birth) and current_semester
    the modules table contains the following attributes:  id(auto incremented), module)name, code(module code),
    and semester it is in.
    the grades table contains the following attributes:  id(from students table), module name(from modules table) and grade%

    this class has the methods for connecting to the database, adding removing or retrieving modules, students and grades,
    it is also linked ot our StudentController class to utilize MVC.

 @author Luke Kenny
 @studentId R00212866
 @Assignment OOP Final Project 40%
 */
public class DBModel {
    private String url;
    private String username;
    private String password;
    Connection conn = null;
    private StudentController controller;

    /**
     * Constructor for the DBModel class. Takes in the url, username(root) and password(root)
     * to connect to the database.
     *
     * @param url      the url of the database
     * @param username the username of the database
     * @param password the password of the database
     */

    public DBModel(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    /**
     * Establishes a connection to the database.
     *
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public void connect() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(url, username, password);
    }
    /**
     * Closes the connection to the database.
     *
     * @throws SQLException
     */

    public void disconnect() throws SQLException {
        if (conn != null) {
            conn.close();
        }
    }

    /**
     * Adds a new student to the database.
     *
     * @param id              the ID of the student
     * @param name            the name of the student
     * @param dob             the date of birth of the student
     * @param currentSemester the current semester of the student
     * @return the ID of the inserted student
     * @throws SQLException
     */

    public String addStudent(String id, String name, String dob, String currentSemester) throws SQLException {
        PreparedStatement stmt = null;
        String insertedId = "";

        try {
            // Inserts the new student into the database
            String sql = "INSERT INTO students (id, name, dob, current_semester) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setDate(3, java.sql.Date.valueOf(dob));
            stmt.setString(4, currentSemester);
            stmt.executeUpdate();

            insertedId = id;
            System.out.println("Student added successfully.");

        } finally {
            // Closes the statement
            if (stmt != null) {
                stmt.close();
            }
        }
        return insertedId;
    }

    /**
     * Removes a student from the database.
     *
     * @param id the ID of the student to remove
     * @throws SQLException
     */
    public void removeStudents(String id) throws SQLException {
        PreparedStatement stmt = null;

        try {
            // Deletes the student from the database
            String sql = "DELETE FROM students WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Student with ID " + id + " removed successfully.");
            } else {
                System.out.println("No student with ID " + id + " found in the database.");
            }

        } finally {
            // Close the statement
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**

     @return a string representation of all students in the database.

     @throws SQLException if there is an error executing the SQL query.
     */
    public String getAllStudents() throws SQLException {

        String query = "SELECT * FROM students";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery(query);
        StringBuilder result = new StringBuilder();
        while (rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String dob = rs.getString("dob");
            String currentSemester = rs.getString("current_semester");
            Student student = new Student(id, name, dob, currentSemester);

            result.append(String.format("ID %s name %s DOB %s Semester %s \n", id, name, dob, currentSemester));
        }
        return result.toString();
    }

    /**
     * Adds a new module to the database.
     *
     * @param module_name the name of the module
     * @param code the module code
     * @param semester the semester it belongs to
     * @return the module name
     * @throws SQLException
     */

    public String addModule(String module_name, String code, String semester) throws SQLException {
        PreparedStatement stmt = null;
        String insertedModuleName = "";

        try {
            // Insert the new module into the database
            String sql = "INSERT INTO modules (module_name, code, semester) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, module_name);
            stmt.setString(2, code);
            stmt.setString(3, semester);
            stmt.executeUpdate();

            insertedModuleName = module_name;
            System.out.println("Module added successfully.");

        } finally {
            // Close the statement
            if (stmt != null) {
                stmt.close();
            }
        }

        return insertedModuleName;
    }

    /**

     @return a string representation of all modules in the database.

     @throws SQLException if there is an error executing the SQL query.
     */
    public String showAllModules() throws SQLException {

        String query = "SELECT * FROM modules";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery(query);
        StringBuilder result = new StringBuilder();
        while (rs.next()) {
            int id = rs.getInt("id");
            String module_name = rs.getString("module_name");
            String code = rs.getString("code");
            String semester = rs.getString("semester");

            Module module = new Module(id, module_name, code, semester);

            result.append(String.format("ID %s Module name %s code %s Semester %s \n", id, module_name, code, semester));
        }
        return result.toString();
    }

    /**
     * Removes a student from the database.
     *
     * @param module_name the module name of the module to remove
     * @throws SQLException
     */

    public void removeModule(String module_name) throws SQLException {
        PreparedStatement stmt = null;

        try {
            // Delete the student from the database
            String sql = "DELETE FROM modules WHERE module_name = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, module_name);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Module " + module_name + " removed successfully.");
            } else {
                System.out.println("No module called " + module_name + " found in the database.");
            }

        } finally {
            // Close the statement
            if (stmt != null) {
                stmt.close();
            }
        }
    }
    /**

     Adds a new grade to the database for a certain inputted student and module.

     @param id the ID of the student

     @param module_name the name of the module

     @param grade the grade to be added

     @return the value of the inserted grade

     @throws SQLException if there is an error accessing the database
     */

    public String addGrade(String id, String module_name, String grade) throws SQLException {
        PreparedStatement stmt = null;
        String insertedGradeValue = "";

        try {
            // Insert the new grade into the database
            String sql = "INSERT INTO grades (id, module_name, grade) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, module_name);
            stmt.setString(3, grade);
            stmt.executeUpdate();

            insertedGradeValue = grade;
            System.out.println("Grade added successfully");

        } finally {
            // Close the statement
            if (stmt != null) {
                stmt.close();
            }
        }

        return insertedGradeValue;
    }


    /**
     * Removes a student from the database.
     *
     * @param id the ID of the student to remove
     * @param module_name the module name of the module to remove
     * @param grade the grade of the student to remove
     * @throws SQLException
     */

    public void removeGrade(String id, String module_name, String grade) throws SQLException {
        PreparedStatement stmt = null;

        try {
            // Delete the student from the database
            String sql = "DELETE FROM grades (id, module_name, grade) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, module_name);
            stmt.setString(3, grade);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Student record containing " + id + module_name + grade + " removed successfully.");
            } else {
                System.out.println("No student record containing " + id + module_name + grade + " found in the database.");
            }

        } finally {
            // Close the statement
            if (stmt != null) {
                stmt.close();
            }
        }
    }
    /**
     * Retrieves all grades from the "grades" table in the database and returns them as a formatted string.
     *
     * @return a string containing all grades in the format "ID [id] Module name [module_name] grade [grade] \n"
     * @throws SQLException if there is an error executing the SQL query
     */
    public String showAllGrades() throws SQLException {

        String query = "SELECT * FROM grades";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        StringBuilder result = new StringBuilder();
        while (rs.next()) {
            String id = rs.getString("id");
            String module_name = rs.getString("module_name");
            String grade = rs.getString("grade");

            result.append(String.format("ID %s Module name %s grade %s \n", id, module_name, grade));
        }
        return result.toString();
    }


    /**

     runs an SQL query to select all grades for students who scored 40 or above, and prints the results to the console.

     This query works by joining the "students", "grades", and "modules" tables based on their relationships.

     @throws SQLException if there is an error executing the SQL query or accessing the database
     */

    public void selectGrade() throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sql = "SELECT students.name, students.id, modules.module_name, grades.grade " +
                    "FROM students " + "INNER JOIN grades ON students.id = grades.id " +
                    "INNER JOIN modules ON grades.module_name = modules.module_name " +
                    "WHERE grades.grade >= 40;"; // filters them as the requirements say

            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();


            while (rs.next()) {
                String name = rs.getString("name");
                String id = rs.getString("id");
                String moduleName = rs.getString("module_name");
                String grade = rs.getString("grade");
                // this prints the students who got 40 or above to the console
                System.out.println(name + " (" + id + ") passed " + moduleName + " with a grade of " + grade + "%");
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }


}







