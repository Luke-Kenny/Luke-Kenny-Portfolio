package com.example.lukeoop;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
// student class for representing the student object
public class Student implements Serializable {
    private String name;
    private String studentID;
    private String dateOfBirth;
    private List<Module> modules;

    public Student(String name, String studentID, String dateOfBirth, String currentSemester) {
        this.name = name;
        this.studentID = studentID;
        this.dateOfBirth = dateOfBirth;
        this.modules = new ArrayList<>();
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", studentID='" + studentID + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", modules=" + modules +
                '}';
    }
}
