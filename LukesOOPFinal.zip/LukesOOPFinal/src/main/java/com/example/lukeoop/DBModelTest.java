package com.example.lukeoop;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * This is the unit test class for my DBModel class, which tests my connecting and disconnecting methods.
 * It uses the SQL Databse called MTU_Records which I created, and it runs on port 3306
 * @author Luke Kenny
 * @studentId R00212866
 * @Assignment OOP FINAL PROJECT 40%
 */
public class DBModelTest {
    private DBModel dbModel;

    /**
     * Here I am setting up the method that initializes a new instance of the DBModel class,
     * with connection details to MTU_Records.
     */
    @BeforeEach
    public void setUp() {
        // Initialize a new instance of the DBModel class with connection details to an existing database
        String url = "jdbc:mysql://localhost:3306/MTU_Records";
        String username = "root";
        String password = "root";
        dbModel = new DBModel(url, username, password);
    }

    /**
     * Tear down method that disconnects from the database.
     * @throws SQLException if an exception occurs while disconnecting from the database.
     */
    @AfterEach
    public void tearDown() throws SQLException {
        // Disconnect from the database
        dbModel.disconnect();
    }

    /**
     * this unit test, tests the connecting and disconnecting methods of my DBModel class.
     * It tries connecting to the database, checks if the connection is valid, then disconnects from the database,
     * and checks if the connection was closed.
     */
    @Test
    public void testConnectAndDisconnect() {
        try {
            // Attempting to connect to the database
            dbModel.connect();
            assertTrue(dbModel.conn.isValid(1));

            // Attempting to disconnect from the database
            dbModel.disconnect();
            assertTrue(dbModel.conn.isClosed());
        } catch (Exception e) {
            fail("An exception occurred while connecting/disconnecting to the database: " + e.getMessage());
        }
    }
}
