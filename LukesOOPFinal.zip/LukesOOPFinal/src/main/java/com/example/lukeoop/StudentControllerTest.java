package com.example.lukeoop;

import javafx.scene.control.ListView;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
/**
  * @author Luke Kenny
  * @studentId R00212866
  * @Assignment OOP FINAL PROJECT 40%
 */

class StudentControllerTest {

    private StudentController controller;

    @BeforeEach
    void setUp() {
        controller = new StudentController();
    }

    @Test
    void addStudents() {
        // Testing adding a new student to the database
        // Setting up the data for a new student
        String id = "123";
        String name = "Patrick";
        String dob = "2002-03-12";
        String currentSemester = "2";

        controller.addStudents(id, name, dob, currentSemester);

        // Checking that the student was successfully added to the database
        ListView<String> studentInfo = new ListView<>();
        controller.displayStudentsTable(studentInfo);
        assertTrue(studentInfo.getItems().contains("123 Patrick 2002-03-12 2"));
    }

    @Test
    void removeStudents() {
        // Testing removing a student from the database
        // Seting up the data for a new student
        String id = "123";
        String name = "Patrick";
        String dob = "2002-03-12";
        String currentSemester = "2";

        controller.addStudents(id, name, dob, currentSemester);
        controller.removeStudents(id);

        // Checking that the student was successfully removed from the database
        ListView<String> studentInfo = new ListView<>();
        controller.displayStudentsTable(studentInfo);
        assertFalse(studentInfo.getItems().contains("123 Patrick 2002-03-12 2"));
    }

    @Test
    void addModules() {
        // Testing adding a new module to the database
        // Setting up the data for a new module
        String moduleName = "C Programming";
        String code = "PROG003";
        String semester = "1";

        controller.addModules(moduleName, code, semester);

        // Checking that the module was successfully added to the database
        ListView<String> moduleInfo = new ListView<>();
        controller.showModulesTable(moduleInfo);
        assertTrue(moduleInfo.getItems().contains("PROG003 C Programming 1"));
    }

    @Test
    void removeModules() {
        // Testing removing a module from the DB
        String moduleName = "C Programming";
        String code = "PROG003";
        String semester = "1";

        controller.addModules(moduleName, code, semester);
        controller.removeModules(moduleName);

        // Checking that the module was successfully removed from the database
        ListView<String> moduleInfo = new ListView<>();
        controller.showModulesTable(moduleInfo);
        assertFalse(moduleInfo.getItems().contains("PROG003 C Programming 1"));
    }

}
