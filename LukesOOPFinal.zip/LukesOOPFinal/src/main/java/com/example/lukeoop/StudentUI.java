package com.example.lukeoop;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * this is my view class which is a modified version of my previous OOP Stage 3 project
 * this utilizes MVC and what I changed was the arrayList system through serialization to instead now be using a DB.
 * the database used is called MTU_Records.

 @author Luke Kenny
 @studentId R00212866
 @Assignment OOP Final Project 40%
 */

public class StudentUI extends Parent {


    StudentController controller = new StudentController();


    private final ListView<String> studentInfo = new ListView<>();

    private final ListView<String> moduleInfo = new ListView<>();

    private final ListView<String> gradeInfo = new ListView<>();

    /**
     * Constructs a new StudentUI object.
     *
     * @param primaryStage the primary stage of the application
     */
    public StudentUI(Stage primaryStage) {

        // displaying tables on startup:
        controller.displayStudentsTable(studentInfo);
        controller.showModulesTable(moduleInfo);
        controller.showGrades(gradeInfo);


        VBox root = new VBox();
        HBox nameBox = new HBox();
        Label nameLabel = new Label("Enter Name ");
        TextField nameField = new TextField();
        nameBox.setAlignment(Pos.CENTER);
        nameBox.getChildren().addAll(nameLabel, nameField);
        nameBox.setSpacing(10);

        HBox sIdBox = new HBox();
        Label sIdLabel = new Label("Enter Student ID ");
        TextField sIdField = new TextField();
        sIdBox.setAlignment(Pos.CENTER);
        sIdBox.getChildren().addAll(sIdLabel, sIdField);
        sIdBox.setSpacing(10);

        HBox dobBox = new HBox();
        Label dobLabel = new Label("Enter Date of Birth ");
        DatePicker dobPicker = new DatePicker();
        dobPicker.setEditable(false);
        dobBox.setAlignment(Pos.CENTER);
        dobBox.getChildren().addAll(dobLabel, dobPicker);
        dobBox.setSpacing(10);

        HBox semesterBox = new HBox();
        Label semesterLabel = new Label("Enter Current Semester ");
        TextField semesterField = new TextField();
        semesterBox.setAlignment(Pos.CENTER);
        semesterBox.getChildren().addAll(semesterLabel, semesterField);
        semesterBox.setSpacing(10);

        HBox inControlBox = new HBox();
        Button removeButton = new Button("Remove");
        Button addButton = new Button("Add");
        inControlBox.setAlignment(Pos.CENTER);
        inControlBox.getChildren().addAll(addButton, removeButton);
        inControlBox.setSpacing(10);




        HBox outControlBox = new HBox();

        Button listButton = new Button("Update student table");

        outControlBox.setAlignment(Pos.CENTER);
        outControlBox.getChildren().addAll(listButton);
        outControlBox.setSpacing(10);

        HBox endControlBox = new HBox();

        Button exitButton = new Button("Exit");
        endControlBox.setAlignment(Pos.BOTTOM_RIGHT);
        endControlBox.getChildren().addAll(exitButton);
        endControlBox.setSpacing(10);


        root.getChildren().addAll(nameBox, sIdBox, dobBox, semesterLabel, semesterField, inControlBox, outControlBox, endControlBox, studentInfo);

        root.setPadding(new Insets(10, 10, 10, 10));
        root.setSpacing(10);
        // new DB implementation
        addButton.setOnAction(e -> {
            String id = sIdField.getText();
            String name = nameField.getText();
            String dob = String.valueOf(dobPicker.getValue());
            String semester = semesterField.getText();
            controller.addStudents(id, name, dob, semester);
        });


        removeButton.setOnAction(e -> {
            String id = sIdField.getText();
            controller.removeStudents(id);
        });

        listButton.setOnAction(e -> {

            controller.displayStudentsTable(studentInfo);

        });

        exitButton.setOnAction(e -> {

                primaryStage.close();

        });
        // create the tab pane
        TabPane tabPane = new TabPane();

        // create the add student tab
        Tab addStudentTab = new Tab("Add Student");
        addStudentTab.setContent(root);
        addStudentTab.setClosable(false);

// Set a default prompt text for the combobox

        Label moduleNameLabel = new Label("Module Name:");

        TextField moduleNameTextField = new TextField();

        Label codeLabel = new Label("Module code");

        TextField codeTextField = new TextField();

        Label semLabel = new Label("Semester");

        TextField moduleSemesterTextField = new TextField();

        Button addModuleButton = new Button("Add Module");
        Button removeModuleButton = new Button("Remove Module");
        Button listModuleButton = new Button("update module list");




// set the layout for Tab 2 (Add Module)
        VBox root2 = new VBox();
        root2.setSpacing(10);
        root2.setPadding(new Insets(10));
        root2.getChildren().addAll(moduleNameLabel, moduleNameTextField, codeLabel, codeTextField, semLabel,
                moduleSemesterTextField, addModuleButton, removeModuleButton, listModuleButton, moduleInfo);

        addModuleButton.setOnAction(e -> {
            String module_name = moduleNameTextField.getText();
            String code = codeTextField.getText();
            String modSemester = moduleSemesterTextField.getText();
            controller.addModules(module_name, code, modSemester);
        });

        listModuleButton.setOnAction(e -> {

            controller.showModulesTable(moduleInfo);

        });

        removeModuleButton.setOnAction(e -> {
            String module_name = moduleNameTextField.getText();
            controller.removeModules(module_name);
        });

// create Tab 2 (Add Module) and add it to the tab pane()
        Tab addModuleTab = new Tab("Add Module", root2);
        addModuleTab.setClosable(false);



// set the layout for Tab 3 (View Records)
        VBox root3 = new VBox();
        root3.setSpacing(10);
        root3.setPadding(new Insets(10));
        Label studIdNameLabel = new Label("Student Id:");

        TextField studIdNameTextField = new TextField();

        Label modNameLabel = new Label("Module Name");

        TextField modNameTextField = new TextField();

        Label gradeLabel = new Label("Grade % ");

        TextField gradeTextField = new TextField();

        Button addGradeButton = new Button("Add Grade");
        Button removeGradeButton = new Button("Remove Grade");
        Button listGradeButton = new Button("Update grade list");
        Button filterButton = new Button("print out passed students >=40");

        addGradeButton.setOnAction(e -> {
            String id = studIdNameTextField.getText();
            String module_name = modNameTextField.getText();
            String grade = gradeTextField.getText();

            controller.addGrades(id, module_name, grade);
        });

        listGradeButton.setOnAction(e -> {

            controller.showGrades(gradeInfo);

        });



        removeGradeButton.setOnAction(e -> {
            String grade = gradeTextField.getText();
            controller.removeGrades(grade);
        });

        filterButton.setOnAction(e -> {

            controller.selectPassed();
        });


        root3.getChildren().addAll(studIdNameLabel, studIdNameTextField, modNameLabel, modNameTextField, gradeLabel, gradeTextField,
        addGradeButton, removeGradeButton, listGradeButton,filterButton, gradeInfo);




// create the third tab
        Tab viewRecords = new Tab("Student Records");
        viewRecords.setClosable(false);
        viewRecords.setContent(root3);


        VBox root4 = new VBox();
        root4.setSpacing(10);
        root4.setPadding(new Insets(10));
        Label memLeakLabel = new Label("Simulates memory leak");
        Button memLeakButton = new Button("testing centre");




        memLeakButton.setOnAction(e -> {
            controller.simulateMemoryLeak();
        });

        root4.getChildren().addAll(memLeakButton, memLeakLabel);

        Tab memLeak = new Tab("memLeak");
        memLeak.setClosable(false);
        memLeak.setContent(root4);

// add all the tabs to the tabPane
        tabPane.getTabs().addAll(addStudentTab, addModuleTab, viewRecords, memLeak);


        // create the root layout
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10));


        Scene scene = new Scene(tabPane, 400, 400);
        scene.getStylesheets().add("/application.css");

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
