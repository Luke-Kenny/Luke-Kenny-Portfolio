package com.example.lukeoop;

import javafx.scene.control.ListView;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 @author Luke Kenny
 @studentId R00212866
 @Assignment OOP Final Project 40%
 */




/**
 *  DBModel object to connect to and interact with the database.
 */
public class StudentController {

    DBModel db = new DBModel("jdbc:mysql://localhost:3306/mtu_records", "root", "root");

    /**
     * Adds a new student to the database.
     *
     * @param id             the student's ID
     * @param name           the student's name
     * @param dob            the student's date of birth
     * @param currentSemester the student's current semester
     */
    public void addStudents(String id, String name, String dob, String currentSemester) {


        try {

            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.addStudent(id, name, dob, currentSemester);
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    /**
     * Removes a student from the database.
     *
     * @param id the student's ID
     */

    public void removeStudents(String id) {


        try {
            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }

        try {
            // Deleting the student with the given ID from the database
            String sql = "DELETE FROM students WHERE id = ?";
            PreparedStatement stmt = db.conn.prepareStatement(sql);
            stmt.setString(1, id);
            int numRowsDeleted = stmt.executeUpdate();

            if (numRowsDeleted == 0) {
                System.out.println("Error, no student with this id " + id + " found.");
            } else {
                System.out.println("Student with ID " + id + " was successfully removed");
            }

            stmt.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Displays a table of all students in the database on a JavaFX ListView.
     *
     * @param studentInfo the JavaFX ListView that displays the information
     */
    public void displayStudentsTable(ListView<String> studentInfo) {
        try {
            db.connect();
            String table = db.getAllStudents();
            studentInfo.getItems().clear();
            studentInfo.getItems().addAll(table);

        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                db.disconnect();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    /**
     * Adds a new module to the database.
     *
     * @param module_name the module's name
     * @param code        the module's code
     * @param semester    the module's semester
     */
    public void addModules(String module_name, String code, String semester) {


        try {

            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.addModule(module_name, code, semester);
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Removes a module from the database.
     *
     * @param module_name the modules name
     */
    public void removeModules(String module_name) {

        try {
            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }

        try {
            // Deleting the module from the modules table
            String sql = "DELETE FROM modules WHERE module_name = ?";
            PreparedStatement stmt = db.conn.prepareStatement(sql);
            stmt.setString(1, module_name);
            int numRowsDeleted = stmt.executeUpdate();

            if (numRowsDeleted == 0) {
                System.out.println("Module " + module_name + "was not found.");
            } else {
                System.out.println("Module  " + module_name + " was successfully removed");
            }

            stmt.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }


    /**
     * Displays a table of all modules in the database on a JavaFX ListView.
     *
     * @param moduleInfo the JavaFX ListView that displays the information
     */
    public void showModulesTable(ListView<String> moduleInfo) {
        try {
            db.connect();
            String table = db.showAllModules();
            moduleInfo.getItems().clear();
            moduleInfo.getItems().addAll(table); // keeps my list up to date
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                db.disconnect();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
    /**
     * Removes a grade from the database.
     *
     * @param grade the grade of the student
     */
    public void removeGrades(String grade) {
        try {
            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }

        try {
            // Deleting the grade with the given value from the database
            String sql = "DELETE FROM grades WHERE grade = ?";
            PreparedStatement stmt = db.conn.prepareStatement(sql);
            stmt.setString(1, grade);
            int numRowsDeleted = stmt.executeUpdate();

            if (numRowsDeleted == 0) {
                System.out.println("Grade " + grade + " was not found.");
            } else {
                System.out.println("Grade " + grade + " was successfully removed.");
            }

            stmt.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Adds a new student grade to the database.
     *
     * @param id the students id
     * @param moduleName name of the module
     * @param grade grade of the student
     */

    public void addGrades(String id, String moduleName, String grade) {
        try {
            db.connect();

            // Retrieving the student id from the students table
            PreparedStatement stmt1 = db.conn.prepareStatement("SELECT id FROM students WHERE id = ?");
            stmt1.setString(1, id);
            ResultSet rs1 = stmt1.executeQuery();

            if (!rs1.next()) {
                System.out.println("Error no student id found");
                return;
            }

            // Retrieving the module name from the modules table
            PreparedStatement stmt2 = db.conn.prepareStatement("SELECT module_name FROM modules WHERE module_name = ?");
            stmt2.setString(1, moduleName);
            ResultSet rs2 = stmt2.executeQuery();

            if (!rs2.next()) {
                System.out.println("No module found");
                return;
            }

            // Inserting the grade into the grades table
            PreparedStatement stmt3 = db.conn.prepareStatement("INSERT INTO grades (id, module_name, grade) VALUES (?, ?, ?)");
            stmt3.setString(1, id);
            stmt3.setString(2, moduleName);
            stmt3.setString(3, grade);
            stmt3.executeUpdate();

            System.out.println("Grade added successfully");
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                db.disconnect();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
    /**
     * Displays a table of all student grades in the database on a JavaFX ListView.
     *
     * @param gradeInfo the JavaFX ListView that displays the information
     */
    public void showGrades(ListView<String> gradeInfo) {
        try {
            db.connect();
            String table = db.showAllGrades();
            gradeInfo.getItems().clear();
            gradeInfo.getItems().addAll(table); // add table data to ListView
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                db.disconnect();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
    }


    /**

     This method selects all the grades of students who have passed.
     @throws RuntimeException if there is a SQL or class not found exception while connecting to the database.
     */
    public String selectPassed() {
        try {

            db.connect();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.selectGrade();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        try {
            db.disconnect();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return null;
    }

    /**
                            MEMORY LEAK
     This method simulates a memory leak by creating an infinitely looping list of Student objects.
     It measures the elapsed time and memory usage until an OutOfMemoryError is thrown.
     @throws OutOfMemoryError when the heap is full and there is no more memory to allocate for the Student objects.
     */
    public void simulateMemoryLeak() {
        List<Student> students = new ArrayList<>();
        long startTime = System.currentTimeMillis();
        long startMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        try {
            while (true) { // Infinitely loops
                Student student = new Student("Mr memory leak", "20", "12344", "1");
                students.add(student);
            }
        } catch (OutOfMemoryError e) {
            long endMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long endTime = System.currentTimeMillis();
            long elapsedTime = endTime - startTime;
            long memoryUsage = endMemory - startMemory;
            System.out.println("Out of memory error occurred after " + elapsedTime + "ms with " + memoryUsage + " bytes used.");
        }
    }

}




