// _ = DOM variables to store DOM elements in the span tag for updating user scores
const userScore_span = document.getElementById("user-score");
const compScore_span = document.getElementById("comp-score");
const scoreBoard_div = document.querySelector(".Score-board");
const result_para = document.querySelector(".game-result > p");
// caching the rock paper scissors variables for usage 
const rock_div = document.getElementById("rock");
const paper_div = document.getElementById("paper");
const scissors_div = document.getElementById("scissors");
// making the processes into vars to save time and shorten code

var userScore = 0; // const wont work as we must change the variable
var compScore = 0;  


// computers choice logic
function findComputersChoice() {
    const moves = ['rock', 'paper', 'scissors'];
    const randomNum = Math.floor(Math.random() * 3);
     // this selects a random number between 0, 1 and 2
     // im rounding down to avoid any decimals like 0.11 for example
     return moves[randomNum]; // randomly selects r, p or s
}

function userWin(userSelect, computerSelect) {
    // increases users score on the scoreboard
    userScore++; 
    // updates the scoreboard for user win
    userScore_span.innerHTML = userScore;
    // no change as comp did not win
    compScore_span.innerHTML = compScore;
    result_para.innerHTML = userSelect + " defeats " + computerSelect + ". User wins!";
}

function computerWin(userSelect, computerSelect) {
    // increases computers score on the scoreboard
    compScore++; 
    // updates the scoreboard for computer win
    compScore_span.innerHTML = compScore;
    // no change as user did not win 
    userScore_span.innerHTML = userScore;
    result_para.innerHTML = userSelect + " loses to " + computerSelect + ". Computer wins!";
   
}

function draw(userSelect, computerSelect) {
    result_para.innerHTML = userSelect + " same as " + computerSelect + ". it's a draw!";
}
 
// game winning logic
function game(userChoice) {
    const computerChoice = findComputersChoice();
    const userChoiceElement = document.getElementById(userChoice);
    const computerChoiceElement = document.getElementById(computerChoice);

    displayComputerChoiceText(computerChoice);
    displayUserChoiceText(userChoice);

    const allChoiceElements = document.querySelectorAll('.choice');
    allChoiceElements.forEach((element) => {
        element.classList.remove('highlightWin', 'highlightLoss', 'highlightDraw');
    }); 

    switch (userChoice + computerChoice) {
        // NOTE: Left word is users choice, right word is computers choice
        case "rockscissors": // using switch statements instead of if statements for ease of use
        case "paperrock":
        case "scissorspaper":
            userWin(userChoice, computerChoice);
            // highlights for winning and losing choice
            userChoiceElement.classList.add('highlightWin');
            computerChoiceElement.classList.add('highlightLoss');
            break;
        case "rockpaper":
        case "paperscissors":
        case "scissorsrock":
            computerWin(userChoice, computerChoice);
            computerChoiceElement.classList.add('highlightWin');
            userChoiceElement.classList.add('highlightLoss');
            break;
        case "rockrock":
        case "paperpaper":
        case "scissorsscissors":
            draw(userChoice, computerChoice);
            userChoiceElement.classList.add('highlightDraw');
            computerChoiceElement.classList.add('highlightDraw');
            break; 
    }
        
    setTimeout(() => {
        allChoiceElements.forEach((element) => {
            element.classList.remove('highlightWin', 'highlightLoss', 'highlightDraw');
        }); // removes the glow effect of a win/loss/draw after 500ms
    }, 500); 
    
}

function displayComputerChoiceText(computerChoice) {
    const computerChoiceTextElement = document.getElementById("computer-choice-display");
    let computerChoiceText = "";
    // function to display a graphical view of what the computer chose
    switch(computerChoice) {
        case "rock":
            computerChoiceText = "Computer Chose Rock";
            break;
        case "paper":
            computerChoiceText = "Computer Chose Paper";
            break;
        case "scissors":
            computerChoiceText = "Computer Chose Scissors";
            break;
    }
    computerChoiceTextElement.textContent = computerChoiceText;
}

function displayUserChoiceText(userChoice) {
    const userChoiceTextElement = document.getElementById("user-choice-display");
    let userChoiceText = "";
        // function to display a graphical view of what the user chose
    switch(userChoice) {
        case "rock":
            userChoiceText = "User Chose Rock";
            break;
        case "paper":
            userChoiceText = "User Chose Paper";
            break;
        case "scissors":
            userChoiceText = "User Chose Scissors";
            break;
    }
    userChoiceTextElement.textContent = userChoiceText;
}


// main function for game.js
function main() {
    // functions for user interaction with the icons
    rock_div.addEventListener('click', function(){
        game("rock");
    }); 

    paper_div.addEventListener('click', function(){
        game("paper");
    }); 

    scissors_div.addEventListener('click', function(){
        game("scissors");
    }); 
}

main(); // main function called