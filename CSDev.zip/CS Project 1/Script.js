document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#login");
    const createAccountForm = document.querySelector("#createAccount");

    // Array to store users Client Side
    const users = [];

    document.querySelector("#linkCreatesAnAccount").addEventListener("click", e => {
        e.preventDefault(); // prevents redirection to the atrium
        loginForm.classList.add("form--hidden");
        createAccountForm.classList.remove("form--hidden");
    });

    document.querySelector("#linkLogin").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.remove("form--hidden");
        createAccountForm.classList.add("form--hidden");
    });

    loginForm.addEventListener("submit", e => {
        e.preventDefault();

        // simulation
        const username = loginForm.querySelector('[placeholder="Username or email"]').value;
        const password = loginForm.querySelector('[placeholder="Password"]').value;

        // Validation of the input fields
        if (username.trim() === "" || password.trim() === "") {
            setFormMessage(loginForm, "error", "Please enter valid inputs");
        } else {
            // Validation of the login
            const user = users.find(u => u.username === username && u.password === password);
            if (user) {
                // Navigation to game.html
                window.location.href = "game.html";
            } else {
                setFormMessage(loginForm, "error", "Invalid username or password");
            }
        }
    });

    createAccountForm.addEventListener("submit", e => {
        e.preventDefault();

        const signupUsername = createAccountForm.querySelector('[placeholder="Username"]').value;
        const email = createAccountForm.querySelector('[placeholder="Email Address"]').value;
        const password = createAccountForm.querySelector('[placeholder="Password"]').value;
        const confirmPassword = createAccountForm.querySelector('[placeholder="Confirm Password"]').value;

        // Validate the input fields
        if (signupUsername.trim() === "" || email.trim() === "" || password.trim() === "" || confirmPassword.trim() === "") {
            setFormMessage(createAccountForm, "error", "Please enter valid inputs");
        } else {
            // Validate the input and create an account
            if (isValidSignup(signupUsername, email, password, confirmPassword)) {
                // Add the user to the array
                users.push({ username: signupUsername, email, password });
                // Navigate to game.html
                window.location.href = "game.html";
            } else {
                setFormMessage(createAccountForm, "error", "Invalid sign-up data");
            }
        }
    });

    function isValidSignup(username, email, password, confirmPassword) {
        // Validate sign-up data (e.g., check if passwords match)
        if (password !== confirmPassword) {
            return false; // Passwords don't match
        }
        // Check if the username or email is already taken
        if (users.some(user => user.username === username || user.email === email)) {
            return false; // Username or email already exists
        }
        return true; // Sign-up data is valid
    }

    function setFormMessage(formElement, type, message) {
        const messageElement = formElement.querySelector(".form__message");

        messageElement.textContent = message;
        messageElement.classList.remove("form__message--success", "form__message--error");
        messageElement.classList.add(`form__message--${type}`);
    }
});
